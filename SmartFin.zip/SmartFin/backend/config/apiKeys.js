module.exports = {

ALPHA_VANTAGE_KEY:"YOUR_API_KEY",
GOV_API_KEY:"YOUR_API_KEY"

};